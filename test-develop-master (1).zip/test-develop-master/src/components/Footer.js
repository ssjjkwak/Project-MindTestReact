import React from 'react';

const Footer = () => {
  return (
    <footer id="footer">
      <div>
        <span className="highlight">React Study </span>
        © 2021
      </div>
    </footer>
  );
}

export default Footer